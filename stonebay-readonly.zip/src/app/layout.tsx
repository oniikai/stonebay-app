import "./globals.css";
import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "StoneBay",
  description: "Marketplace del marmo — vetrina read-only",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="it">
      <body>
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur border-b">
          <div className="container py-3 flex items-center gap-3">
            <Link href="/" className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-xl bg-black text-white flex items-center justify-center font-bold">SB</div>
              <div className="font-extrabold text-lg">StoneBay</div>
            </Link>
            <nav className="ml-6 hidden md:flex gap-4 text-sm">
              <Link href="/embed/gallery" className="hover:underline">Embed gallery</Link>
              <Link href="/privacy" className="hover:underline">Privacy</Link>
              <Link href="/tos" className="hover:underline">Termini</Link>
            </nav>
          </div>
        </header>
        <main className="min-h-dvh">{children}</main>
        <footer className="border-t mt-10">
          <div className="container py-6 text-sm text-neutral-500 flex flex-wrap items-center justify-between gap-2">
            <div>© {new Date().getFullYear()} StoneBay</div>
            <div className="flex gap-3">
              <a className="hover:underline" href="/privacy">Privacy</a>
              <a className="hover:underline" href="/tos">Termini</a>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}

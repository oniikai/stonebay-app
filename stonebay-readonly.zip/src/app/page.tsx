import Link from "next/link";

export default function HomePage() {
  return (
    <section className="container py-12">
      <div className="grid md:grid-cols-2 gap-6 items-center">
        <div className="space-y-5">
          <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">
            Con il marmo <span className="text-[var(--sb-accent)]">ogni ambiente</span><br/> diventa emozione.
          </h1>
          <p className="text-neutral-700 max-w-prose">
            Questa è la vetrina <strong>read-only</strong> di StoneBay con dati di esempio.
            Ideale da embeddare nel sito Framer come anteprima del marketplace.
          </p>
          <div className="flex gap-3">
            <Link href="/embed/gallery" className="btn-primary">Apri galleria</Link>
            <a href="/api/public/listings" className="btn-outline">API pubblica</a>
          </div>
        </div>
        <div className="card overflow-hidden">
          <img
            alt="Marmo"
            src="https://images.unsplash.com/photo-1616512659450-407e1680adc8?q=80&w=1400&auto=format&fit=crop"
            className="w-full h-[320px] object-cover"
          />
        </div>
      </div>
      <div className="mt-12 grid md:grid-cols-3 gap-4">
        {[
          ["Eleganza", "UI minimal, serietà e materiali protagonisti."],
          ["Trasparenza", "La vetrina non mostra prezzi; solo mock dati."],
          ["Scalabilità", "In futuro si collega a backend e ruoli."],
        ].map(([t, s]) => (
          <div key={t} className="card p-4">
            <div className="text-lg font-bold">{t}</div>
            <div className="text-neutral-700">{s}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

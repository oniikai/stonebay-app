import { NextResponse } from "next/server";

const listings = [
  {
    "id": 1,
    "type": "lastre",
    "material": "Calacatta (Mock)",
    "color": "Bianco",
    "finish": "lucida",
    "thickness_mm": 20,
    "sqm_total": 80,
    "location": "Massa, IT",
    "price_eur_sqm": null,
    "images": [
      "https://images.unsplash.com/photo-1542484053-3a5b4a1c57d7?q=80&w=1400&auto=format&fit=crop"
    ],
    "notes": "Esempio di lotto mock",
    "created_at": "2025-08-08T00:00:00Z"
  },
  {
    "id": 2,
    "type": "blocco",
    "material": "Arabescato (Mock)",
    "color": "Bianco/Grigio",
    "finish": "grezzo",
    "thickness_mm": null,
    "sqm_total": 120,
    "location": "Seravezza, IT",
    "price_eur_sqm": null,
    "images": [
      "https://images.unsplash.com/photo-1546808708-2533a9e53727?q=80&w=1400&auto=format&fit=crop"
    ],
    "notes": "Solo dimostrativo",
    "created_at": "2025-08-05T00:00:00Z"
  },
  {
    "id": 3,
    "type": "lastre",
    "material": "Statuario (Mock)",
    "color": "Bianco",
    "finish": "levigata",
    "thickness_mm": 30,
    "sqm_total": 60,
    "location": "Carrara, IT",
    "price_eur_sqm": null,
    "images": [
      "https://images.unsplash.com/photo-1519710164239-da123dc03ef4?q=80&w=1400&auto=format&fit=crop"
    ],
    "notes": "Placeholder",
    "created_at": "2025-08-02T00:00:00Z"
  }
] as const;

export async function GET() {
  const res = NextResponse.json({ items: listings }, { status: 200 });
  // Allow embedding/fetching from Framer and anywhere during demo
  res.headers.set("Access-Control-Allow-Origin", "*");
  res.headers.set("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.headers.set("Access-Control-Allow-Headers", "Content-Type");
  return res;
}

export async function OPTIONS() {
  const res = new NextResponse(null, { status: 204 });
  res.headers.set("Access-Control-Allow-Origin", "*");
  res.headers.set("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.headers.set("Access-Control-Allow-Headers", "Content-Type");
  return res;
}

"use client";
import { useEffect, useState } from "react";
type Item = {
  id: number;
  type: string;
  material: string;
  color?: string | null;
  finish?: string | null;
  thickness_mm?: number | null;
  sqm_total: number;
  location: string;
  images: string[];
  notes?: string | null;
};

export default function EmbedGallery() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/public/listings", { cache: "no-store" });
        const json = await res.json();
        setItems(json.items || []);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  return (
    <div className="container py-6">
      <h1 className="text-xl font-bold mb-3">Vetrina StoneBay (demo)</h1>
      {loading ? <div className="text-neutral-600">Caricamento…</div> : null}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((l) => (
          <div key={l.id} className="card overflow-hidden">
            <div className="aspect-video bg-neutral-100 overflow-hidden">
              {l.images?.[0] ? (
                <img src={l.images[0]} alt={l.material} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-neutral-400">Nessuna immagine</div>
              )}
            </div>
            <div className="p-4 space-y-1">
              <div className="font-semibold text-lg">{l.material} <span className="text-neutral-500 font-normal">· {l.type}</span></div>
              <div className="text-sm text-neutral-700 flex flex-wrap gap-x-4 gap-y-1">
                <span><strong>MQ totali:</strong> {l.sqm_total}</span>
                <span><strong>Luogo:</strong> {l.location}</span>
                {l.finish ? <span><strong>Finitura:</strong> {l.finish}</span> : null}
                {l.thickness_mm ? <span><strong>Spessore:</strong> {l.thickness_mm} mm</span> : null}
              </div>
              <div className="text-xs text-neutral-500">{l.notes || "—"}</div>
              <div className="pt-2 text-neutral-400 text-sm">Prezzo non disponibile in vetrina</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

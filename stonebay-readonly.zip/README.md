# StoneBay — Vetrina Read-Only (Next.js)

Demo pronta per:
- **API pubblica** `GET /api/public/listings` con dati **mock**
- **Galleria embeddabile** `/embed/gallery` (puoi iframe su Framer)
- **Homepage** con hero: “Con il marmo ogni ambiente diventa emozione.”

## Sviluppo locale
```bash
npm i
npm run dev
# apri http://localhost:3000
```

## Deploy su Vercel
1) Crea un repo su GitHub e pusha questi file
2) Su Vercel: Import Project → collega il repo → Deploy
3) Otterrai un dominio tipo `https://stonebay-readonly.vercel.app`

## Integrare in Framer (2 opzioni)

### Opzione A: **Embed come iframe**
Nel tuo Framer, aggiungi un *Embed* con HTML:
```html
<iframe
  src="https://YOUR_DOMAIN/embed/gallery"
  style="width:100%;height:800px;border:0;border-radius:16px;overflow:hidden"
  loading="lazy"
></iframe>
```

### Opzione B: **Fetch dell’API e render con Code Component** (solo read-only)
- In Framer, usa un Code Component (se hai piano che lo supporta) e fai `fetch('https://YOUR_DOMAIN/api/public/listings')`.
- Renderizza card statiche (ricorda: nessun prezzo in questa API).

> L’API imposta CORS `*` per permettere l’uso anche da framer-preview.

## Note
- Tutti i dati sono mock/placeholder, **nessun dato reale**.
- Quando vorrai passare al marketplace vero, separeremo:
  - Marketing (Framer)
  - App (Next.js + backend), con auth, ruoli e prezzi server-side.
